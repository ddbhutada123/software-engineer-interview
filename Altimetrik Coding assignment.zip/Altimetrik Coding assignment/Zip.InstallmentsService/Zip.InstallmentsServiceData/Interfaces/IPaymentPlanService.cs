﻿using System;
using System.Collections.Generic;
using System.Text;
using Zip.InstallmentsServiceData.Models;
using Zip.InstallmentsServiceEntity.DataTrnsfrObj;

namespace Zip.InstallmentsServiceData.Interfaces
{
    public interface IPaymentPlanService
    {
        PaymentPlan CreatePaymentPlan(PaymentPlanData requestObj);
        PaymentPlan GetPaymentPlanById(Guid id);
    }
}
