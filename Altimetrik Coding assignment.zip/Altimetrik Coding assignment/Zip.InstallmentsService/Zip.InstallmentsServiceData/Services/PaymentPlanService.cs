﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Zip.InstallmentsServiceData.Interfaces;
using Zip.InstallmentsServiceData.Models;
using Zip.InstallmentsServiceEntity.DataTrnsfrObj;

namespace Zip.InstallmentsServiceData.Services
{
    public class PaymentPlanService : IPaymentPlanService
    {
        private readonly ServiceContext _context;

        /// <summary>
        /// Intialization in Constructor 
        /// </summary>
        /// <param name="context"></param>
        public PaymentPlanService(ServiceContext context)
        {
            _context = context;
        }

        /// <summary>
        /// To get payment plan by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public PaymentPlan GetPaymentPlanById(Guid id)
        {
            var result = _context.PaymentPlans.Where(x => x.Id == id).Include(x => x.Installments)?.FirstOrDefault();
            return result;
        }

        /// <summary>
        /// Create payment plan
        /// </summary>
        /// <param name="_paymentPlan"></param>
        /// <returns></returns>
        public PaymentPlan CreatePaymentPlan(PaymentPlanData _paymentPlan)
        {
            var paymenPlan = new PaymentPlan
            {
                Id = _paymentPlan.Id,
                UserId = _paymentPlan.UserId,
                BuyAmount = _paymentPlan.BuyAmount,
                BuyeDate = _paymentPlan.BuyDate,
                NoOfInstallments = _paymentPlan.NoOfInstallments,
                FrequencyInDays = _paymentPlan.FrequencyInDays,
                CreatedOn = DateTime.UtcNow,
                CreatedBy = _paymentPlan.UserId
            };
            _context.PaymentPlans.Add(paymenPlan);

            foreach (var item in _paymentPlan?.Installments)
            {
                var installment = new Installment
                {
                    Id = item.Id,
                    PaymentPlanId = item.PaymentPlanId,
                    DueDate = item.DueDate,
                    Amount = item.Amount,
                    CreatedOn = item.CreatedOn,
                    CreatedBy = item.CreatedBy
                };
                _context.Installments.Add(installment);
            }

            _context.SaveChanges();
            return paymenPlan;
        }


    }
}
