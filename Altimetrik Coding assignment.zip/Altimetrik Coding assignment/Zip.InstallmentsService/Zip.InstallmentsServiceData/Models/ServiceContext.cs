﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;

namespace Zip.InstallmentsServiceData.Models
{
    public class ServiceContext : DbContext
    {
        public ServiceContext(DbContextOptions<ServiceContext> options)
            : base(options)
        {
        }

        public DbSet<PaymentPlan> PaymentPlans { get; set; }

        public DbSet<Installment> Installments { get; set; }
    }
}
