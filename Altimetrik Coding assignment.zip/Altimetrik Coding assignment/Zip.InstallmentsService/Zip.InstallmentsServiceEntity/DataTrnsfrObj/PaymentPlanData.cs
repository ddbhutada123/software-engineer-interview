﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zip.InstallmentsServiceEntity.DataTrnsfrObj
{
    public class PaymentPlanData
    {
        public Guid Id { get; set; }
        public Guid UserId { get; set; }
        public decimal BuyAmount { get; set; }
        public DateTime BuyDate { get; set; }
        public int NoOfInstallments { get; set; }
        public int FrequencyInDays { get; set; }
        public List<InstallmentData> Installments { get; set; }

    }

    public class CreatePaymentPlanData
    {
        public Guid Id { get; set; }
        public Guid UserId { get; set; }
        public decimal BuyAmount { get; set; }
        public DateTime BuyDate { get; set; }
        public int NoOfInstallments { get; set; }
        public int FrequencyInDays { get; set; }

    }
}
