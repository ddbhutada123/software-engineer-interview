﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zip.InstallmentsServiceEntity.DataTrnsfrObj
{
    public class ValidateRequest
    {
        public bool IsValid { get; set; }
        public string Message { get; set; }
    }
}
