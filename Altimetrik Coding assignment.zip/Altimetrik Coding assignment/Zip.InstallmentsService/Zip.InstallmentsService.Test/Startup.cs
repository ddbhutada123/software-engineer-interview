﻿using AutoMapper;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using Zip.InstallmentsService.Interfaces;
using Zip.InstallmentsServiceData.Interfaces;
using Zip.InstallmentsServiceData.Services;
using Zip.InstallmentsService.Factory;

namespace Zip.InstallmentsService.Test
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());

            var serviceProvider = services.BuildServiceProvider();

            services.AddScoped<IPaymentPlanFactory, PaymentPlanFactory>();
            services.AddScoped<IPaymentPlanService, PaymentPlanService>();
            services.AddScoped<IInstallmentFactory, InstallmentFactory>();

            //Mock your repositories.
            Initializer.RegisterMockRepositories(services);
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();
        }
    }
}
