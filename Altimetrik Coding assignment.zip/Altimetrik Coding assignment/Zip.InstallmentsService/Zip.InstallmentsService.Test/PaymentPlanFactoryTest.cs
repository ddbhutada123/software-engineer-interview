﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using Zip.InstallmentsServiceEntity.DataTrnsfrObj;

namespace Zip.InstallmentsService.Test
{
    [TestClass]
    public class PaymentPlanFactoryTest
    {

        [TestMethod]
        public void PaymentPlanWithValidData()
        {
            // Arrange
            CreatePaymentPlanData request = this.MockRequestObject(4, 14);
            PaymentPlanData responseObj = this.MockResponseObject(request.Id, request.UserId, request.BuyDate, request.NoOfInstallments, request.FrequencyInDays);

            //Act
            var MockPaymentPlanFactory = Initializer.MockPaymentPlanFactory;
            MockPaymentPlanFactory.Setup
                  (x => x.Create(request)).Returns(responseObj);

            // Assert
            Assert.AreNotEqual(null, responseObj);
        }

        [TestMethod]
        public void PaymentPlanWithInValidData()
        {
            // Arrange
            CreatePaymentPlanData request = this.MockRequestObject(0, 0);
            PaymentPlanData responseObj = null;

            //Act
            var MockPaymentPlanFactory = Initializer.MockPaymentPlanFactory;
            MockPaymentPlanFactory.Setup
                  (x => x.Create(request)).Returns(responseObj);

            // Assert
            Assert.AreEqual(null, responseObj);
        }

        private CreatePaymentPlanData MockRequestObject(int noOfInstallments, int frequencyInDays)
        {
            CreatePaymentPlanData request = new()
            {
                Id = Guid.NewGuid(),
                UserId = Guid.Parse("d6a182a8051744fdacb9e3708cb45a5a"),
                BuyDate = DateTime.UtcNow,
                NoOfInstallments = noOfInstallments,
                FrequencyInDays = frequencyInDays
            };
            return request;
        }
        private PaymentPlanData MockResponseObject(Guid id, Guid userId, DateTime date, int noOfInstallments, int frequencyInDays)
        {
            PaymentPlanData response = new()
            {
                Id = Guid.NewGuid(),
                UserId = Guid.Parse("d6a182a8051744fdacb9e3708cb45a5a"),
                BuyDate = DateTime.UtcNow,
                NoOfInstallments = noOfInstallments,
                FrequencyInDays = frequencyInDays
            };

            return response;
        }

    }
}
