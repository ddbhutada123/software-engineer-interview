﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using Zip.InstallmentsService.Interfaces;
using Zip.InstallmentsServiceData.Interfaces;
using Zip.InstallmentsServiceData.Services;
using Zip.InstallmentsService.Factory;
using Microsoft.AspNetCore.TestHost;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;

namespace Zip.InstallmentsService.Test
{
    [TestClass]
    public class Initializer
    {
        public static HttpClient TestHttpClient;
        public static Mock<IPaymentPlanFactory> MockPaymentPlanFactory;
        public static Mock<IPaymentPlanService> MockPaymentPlanService;
        public static Mock<IInstallmentFactory> MockInstallmentFactory;

        [AssemblyInitialize]
        public static void InitializeTestServer(TestContext testContext)
        {
            var testServer = new TestServer(new WebHostBuilder()
               .UseStartup<Startup>()
               .UseEnvironment("UnitTest"));

            TestHttpClient = testServer.CreateClient();
        }

        public static void RegisterMockRepositories(IServiceCollection services)
        {
            MockPaymentPlanFactory = (new Mock<IPaymentPlanFactory>());
            services.AddSingleton(MockPaymentPlanFactory.Object);

            //add more mock repositories below
            MockPaymentPlanService = (new Mock<IPaymentPlanService>());
            services.AddSingleton(MockPaymentPlanService.Object);

            MockInstallmentFactory = (new Mock<IInstallmentFactory>());
            services.AddSingleton(MockInstallmentFactory.Object);
        }
    }
}
