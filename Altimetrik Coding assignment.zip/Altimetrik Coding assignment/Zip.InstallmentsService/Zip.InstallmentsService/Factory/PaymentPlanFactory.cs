﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zip.InstallmentsService.Interfaces;
using Zip.InstallmentsServiceData.Interfaces;
using Zip.InstallmentsServiceEntity.DataTrnsfrObj;

namespace Zip.InstallmentsService.Factory
{
    public class PaymentPlanFactory : IPaymentPlanFactory
    {
        private readonly IPaymentPlanService _paymentPlanService;
        private readonly IInstallmentFactory _installmentFactory;
        private IMapper _mapper { get; }

        /// <summary>
        /// Intialization in Constructor
        /// </summary>
        /// <param name="paymentPlanService"></param>
        /// <param name="installmentFactory"></param>
        /// <param name="mapper"></param>
        public PaymentPlanFactory(IPaymentPlanService paymentPlanService, IInstallmentFactory installmentFactory, IMapper mapper)
        {
            _paymentPlanService = paymentPlanService;
            _installmentFactory = installmentFactory;
            _mapper = mapper;
        }

        /// <summary>
        /// Get Payment plan by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public PaymentPlanData GetById(Guid id)
        {
            var response = _paymentPlanService.GetPaymentPlanById(id);
            return Mapper.Map<PaymentPlanData>(response);
        }

        /// <summary>
        /// Logic to create payment plan
        /// </summary>
        /// <param name="requestModel"></param>
        /// <returns></returns>
        public PaymentPlanData Create(CreatePaymentPlanData requestModel)
        {
            //Validate request
            var validateRequest = this.ValidateCreateRequest(requestModel);
            if (!validateRequest.IsValid) return null;

            //convert via AutoMapper
            var paymentPlanDto = Mapper.Map<PaymentPlanData>(requestModel);

            //Calculate installments
            paymentPlanDto.Installments = _installmentFactory.CalculateInstallments(paymentPlanDto)?.ToList();

            //Create Payment plan
            var response = _paymentPlanService.CreatePaymentPlan(paymentPlanDto);

            return Mapper.Map<PaymentPlanData>(response);
        }


        /// <summary>
        /// Validate Payment plan create request
        /// </summary>
        /// <param name="requestModel"></param>
        /// <returns></returns>
        public ValidateRequest ValidateCreateRequest(CreatePaymentPlanData requestModel)
        {
            var responemodel = new ValidateRequest();
            if (requestModel == null) responemodel.Message = "Bad Request.";
            else if (requestModel.NoOfInstallments == 0) responemodel.Message = "Please select number of installments.";
            else if (requestModel.FrequencyInDays == 0) responemodel.Message = "Please select frequency.";

            responemodel.IsValid = true;
            return responemodel;
        }

    }
}
