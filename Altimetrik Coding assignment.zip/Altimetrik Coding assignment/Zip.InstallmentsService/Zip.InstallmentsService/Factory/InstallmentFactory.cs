﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zip.InstallmentsService.Interfaces;
using Zip.InstallmentsServiceEntity.DataTrnsfrObj;

namespace Zip.InstallmentsService.Factory
{
    public class InstallmentFactory : IInstallmentFactory
    {
        /// <summary>
        /// Logic to calculate installment
        /// </summary>
        /// <param name="requestModel"></param>
        /// <returns></returns>
        public List<InstallmentData> CalculateInstallments(PaymentPlanData requestModel)
        {
            List<InstallmentData> installments = new List<InstallmentData>();

            var buyDate = requestModel.BuyDate; 
            var buyAmount = requestModel.BuyAmount; 
            var noOfInstallments = requestModel.NoOfInstallments; 
            var frequencyInDays = requestModel.FrequencyInDays;
            var installmentAmount = this.GetNextInstallmentAmount(buyAmount, noOfInstallments, frequencyInDays);

            InstallmentData installment;
            var nextInstallmentDate = buyDate;
            for (int i = 1; i <= requestModel.NoOfInstallments; i++)
            {
                installment = new InstallmentData();
                installment.Id = System.Guid.NewGuid();
                installment.PaymentPlanId = requestModel.Id;

                if (i > 1) nextInstallmentDate = nextInstallmentDate.AddDays(frequencyInDays).Date;
                installment.DueDate = nextInstallmentDate.Date;
                installment.Amount = installmentAmount;

                installment.CreatedOn = DateTime.UtcNow;
                installment.CreatedBy = requestModel.UserId;

                installments.Add(installment);
            }

            return installments;
        }

        /// <summary>
        /// Logic to get next installment amount
        /// </summary>
        /// <param name="buyAmount"></param>
        /// <param name="noOfInstallments"></param>
        /// <param name="frequencyInDays"></param>
        /// <returns></returns>
        private decimal GetNextInstallmentAmount(decimal buyAmount, int noOfInstallments, int frequencyInDays)
        {
            decimal result = 0;
            if (noOfInstallments == 0) return result;
            decimal installmentAmount = Convert.ToDecimal(buyAmount / noOfInstallments);
            return installmentAmount;
        }

    }
}
