﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zip.InstallmentsServiceEntity.DataTrnsfrObj;

namespace Zip.InstallmentsService.Interfaces
{
    public interface IPaymentPlanFactory
    {
        ValidateRequest ValidateCreateRequest(CreatePaymentPlanData requestModel);
        PaymentPlanData Create(CreatePaymentPlanData requestModel);
        PaymentPlanData GetById(Guid id);
    }
}
