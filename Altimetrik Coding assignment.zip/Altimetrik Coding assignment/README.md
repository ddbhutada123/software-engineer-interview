# ZIP Installment service project
- This API is built in .net core 3.1 and created from Visual studio 2019.
- This includes Depandency injection, repository pattern, SOLID design principles, EF In Memory database, automapper, swagger.
	
- There are below layers to this application
   1) Zip.InstallmentsService.API (API controllers)
   2) Zip.InstallmentsService (Bussiness logic)
   3) Zip.InstallmentsService.Data (Data layer)
   4) Zip.InstallmentsService.Entity (Dto and request/response objects)
   5) Zip.InstallmentsService.Test (Unit test solution) 

## Requirements
Microsoft Visual Studio Community 2019 (64-bit)
.Net Core 3.1

## Install
cd Zip.InstallmentsService
dotnet restore

## Quick Start
cd Zip.InstallmentsService
dotnet run

## Run Tests
cd Zip.InstallmentsService
dotnet test Zip.InstallmentsService.Test.sln

## Testing steps or details
Now to test this API perform below steps
- Make sure Zip.InstallmentsService.API is set as a start project
- Run the project from visual studio 2019 and it shuld open swagger UI page (https://localhost:44398/swagger/index.html)
- Now here you will see 2 api one is to create payment plan (HttpPOST) and one is to get payment plan by PaymentPlanId (HttpGet)
- So you can click on 'Try it out' button and provide input and test it there on swagger UI itself.
  
  OR 
- if you wish to test it via PostMan you can test it via postman as well.